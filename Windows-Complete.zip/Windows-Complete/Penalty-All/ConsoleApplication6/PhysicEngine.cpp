// PhysicEngine.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "PhysicEngine.h"


int _tmain(int argc, _TCHAR* argv[])
{
	PhysicEngine p;


	return 0;
}

