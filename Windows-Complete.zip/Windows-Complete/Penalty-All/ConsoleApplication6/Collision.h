#ifndef COLLISION_H
#define COLLISION_H

#include "Vector3.h"

class Collision
{
public:

	Collision(const bool cols, const Vector3& direction) :
		colState(cols),
		direction(direction) {}

	/** Basic getter for colState */
	inline bool getcolState() const { return colState; }
	/** Basic getter for Distance */
	inline float getDistance()     const { return direction.length(); }
	/** Basic getter */
	inline const Vector3& getDirection() const { return direction; }

private:
	/** Whether or not the objects are intersecting */
	const bool  colState;
	/** The collision normal, with length set to distance. */
	const Vector3 direction;
};
#endif