#ifndef ENGINE_H
#define ENGINE_H

#include "PhysicObj.h"
#include "Ball.h"
#include <vector>
#define RADIUS 2.118f
#define RADIUS_KALE 0.42f
#define FS 0.01f
#define FILE_FS 0.35f

//******///
/*file fs==> 0.35 ali kod kald�r�ld���nda d�zeliyor*/
//////*//////
class PhysicEngine
{
public:

	PhysicEngine() {
		leftVibrate=false;
		rightVibrate=false;
		
		
	}

	inline const PhysicObj& getObject(unsigned int index) const 
	{ 
		return objects[index]; 
	}

	inline unsigned int getNumObjects() const 
	{ 
		return (unsigned int)objects.size();
	}

	void addObject(const PhysicObj& object)
	{
		objects.push_back(object);
	}

	
	Vector3 getBall()
	{
		return objects[0].getPosition();
		
	}

	Vector3 getGloveLeft()
	{
		return objects[1].getPosition();
		
	}
	Vector3 getVelocity(){
		return objects[0].getVelocity();
	}
	Vector3 getGloveRight()
	{
		return objects[2].getPosition();
		
	}

	void setVelocityBall(Vector3 v){
		objects[0].setStatic(false);
		objects[0].setVelocity(v);
	}
	void setGlove(Vector3 gloveLeft,Vector3 gloveRight){
		objects[1].setPosition(gloveLeft);
		objects[2].setPosition(gloveRight);
	}

	// update objects positions and velocities on time interval 
	void update(float delta)
	{ 
		// OLD POSITIONS.
		this->posX = objects[0].getPosition().getX();
		this->posY = objects[0].getPosition().getY();
		this->posZ = objects[0].getPosition().getZ();
		
		if(!objects[0].getStatic())
			objects[0].integrate(delta);
			
		handleCollisions();
		//for(unsigned int i=0; i<objects.size(); ++i){
			//std::cout<< i << ": ("<<objects[i].getPosition().getX()<<", "<<objects[i].getPosition().getY()<<", "
			//<<objects[i].getPosition().getZ()<<"),  ";
		//}
		//std::cout<<std::endl;
	}

	void setGoal(Vector3 v1, Vector3 v2, Vector3 v3, Vector3 v4, float r)
	{
		this->v1 = v1;
		this->v3 = v3;

		float numofSphere = ( v2.getY()-v1.getY() )/(r/2)-1;
		for (float i = 1; i <= numofSphere; i += 1)
		{
			Vector3 center(v1.getX(),v1.getY()+i*(r/2),v1.getZ());/*127.21 12 -455           164.8 12 -455*/
			PhysicObj o1( new Ball(center, r/2),Vector3(0.0f, 0.0f, 0.0f)  ,true);
			addObject(o1);
			//std::cout<<center.getX()<<", "<<center.getY()<<", "<<center.getZ()<<"\n";
		}
		 numofSphere = ( v3.getX()-v2.getX() )/(r/2);
		for (float i = 1; i <= numofSphere; i += 1)
		{
			Vector3 center(v2.getX()+i*(r/2),v2.getY(),v2.getZ());
			PhysicObj o1( new Ball(center, r/2),Vector3(0.0f, 0.0f, 0.0f)  ,true);
			addObject(o1);
			//std::cout<<center.getX()<<", "<<center.getY()<<", "<<center.getZ()<<"\n";
		}
		 numofSphere = ( v3.getY()-v4.getY() )/(r/2)-1;
		for (float i = 1; i <= numofSphere; i += 1)
		{
			Vector3 center(v4.getX(),v4.getY()+i*(r/2),v4.getZ());
			PhysicObj o1( new Ball(center, r/2),Vector3(0.0f, 0.0f, 0.0f)  ,true);
			addObject(o1);
			//std::cout<<center.getX()<<", "<<center.getY()<<", "<<center.getZ()<<"\n";
		}
	}
	bool isStop(){
		return ((int)objects[0].getVelocity().getX()==0 &&
			(int)objects[0].getVelocity().getZ()==0 &&
			(int)objects[0].getVelocity().getY()==0);
	}
	bool isGoal()
	{
		
		bool isgool=( (v1.getX() < objects[0].getPosition().getX() && objects[0].getPosition().getX() < v3.getX()) &&
			(v1.getY() <= objects[0].getPosition().getY() && objects[0].getPosition().getY()+RADIUS < v3.getY()) && 
			v1.getZ() + RADIUS <  objects[0].getPosition().getZ() && objects[0].getPosition().getZ() < -443.f );
		if(isgool){
			//std::cout<<objects[0].getPosition().getX()<<" " << objects[0].getPosition().getY()<<" "<<objects[0].getPosition().getZ()<<std::endl;
			//std::cout<<v1.getX()<<" "<<v1.getY()<<v3.getX()<<" "<<v3.getY()<<std::endl;
		}
		/*if(isgool)
			printBall();*/
		return isgool ;
	}

	Vector3 getRotate(){
		Vector3 old(posX,posY,posZ);
		return ( this->getBall() - old);
	}

	void setDuzlem(float d){
		this->duzlem = d;
	}
	bool getLeftVibrate(){
		return leftVibrate;
	}
	bool getRightVibrate(){
		return rightVibrate;
	}
	void setLeftVibrate(bool b){
		leftVibrate=b;
	}
	void setRightVibrate(bool b){
		rightVibrate=b;
	}
	void setBallPositionVelocity(){
		/*float x = 509;
	float y = 0;
	float z = -149;*/
		objects[0].setPosition(Vector3(150, RADIUS, -512));
		objects[0].setVelocity(Vector3(0,0,0));
	}
private:

	void handleCollisions()
	{
		helperHandle();

		if((objects[0].getPosition().getY() <= duzlem ) && objects[0].getVelocity().getY() < 0.0 ){
			float x = objects[0].getVelocity().getX();
			float z = objects[0].getVelocity().getZ();
			float y = objects[0].getVelocity().getY();

			y = (-3.0 / 4.0 )* y - 0.5f*9.8f*0.01f;
			if(esitBigF(objects[0].getVelocity().getY() , -ZERO) ){
				y= 0;
				objects[0].setPosition(Vector3(objects[0].getPosition().getX(),RADIUS,objects[0].getPosition().getZ()));
			}			
			objects[0].setVelocity(Vector3(x, y,z));
			
		}
		
		
		//sadece y de h�z o oldu�unda x ve z ye s�rt�nme verdik nur
		if(esitF(objects[0].getVelocity().getY(),0) &&esitF(objects[0].getPosition().getY(),0)){
			
			float x,z,x1,z1;

			x = objects[0].getVelocity().getX();
			z = objects[0].getVelocity().getZ();

			x1 = fabs(x) - FS * 9.8f ;
			z1 = fabs(z) - FS * 9.8f ;

			if(FS * 9.8f > x1)
				x1 = 0;
			else if(x < 0)
				x1 = -x1;

			if(FS * 9.8f > z1)
				z1 = 0;
			else if(z < 0)
				z1 = -z1;

			objects[0].setVelocity(Vector3(x1,0,z1));
			
		}

		for(unsigned int i = 1; i < objects.size(); i++)
		{
				Collision intersectData = 
					objects[0].getCollider().collision(
						objects[i].getCollider());

				if(intersectData.getcolState())
				{
					if(i==1 )
						leftVibrate=true;
					if(i==2)
						rightVibrate=true;
					
					Vector3 direction = intersectData.getDirection().normalized();
					Vector3 otherDirection = Vector3(direction.reflect(objects[0].getVelocity().normalized()));
				
					objects[0].setVelocity(Vector3(objects[0].getVelocity().reflect(otherDirection)));
						
				}
		}
		
	}
	
// handle  file .
void helperHandle(){
		float x,y,z,vx,vy,vz;

		x = this->getBall().getX();
		y = this->getBall().getY();
		z = this->getBall().getZ();

		vx = objects[0].getVelocity().getX();
		vy = objects[0].getVelocity().getY();
		vz = objects[0].getVelocity().getZ();

		 //printBall();
		alttan = false;
		// stadyum sinirlari ...
		setStadium(10,300,-10,100,-350,-600);
		//alican 13:42
		if((esitBigF( x,v1.getX()-RADIUS) ) && esitBigF((v3.getX()+RADIUS),x)&& 
			esitBigF(z,v1.getZ()+RADIUS) && esitBigF(-443+RADIUS,z) && 
			esitBigF((v3.getY()+RADIUS),y)&& esitBigF( y,(v1.getY()-RADIUS)) ){
				//std::cout<<"z:"<<z<<"\n";
			    // - yonden + ya h�z� + ise
				if(!esitF(vz,0)){
				//	std::cout <<"vz s�f�r\n";
					if( (esitBigF(z,-443.0f-RADIUS) &&  esitBigF(-443.0f+RADIUS,z )) && ((posZ-z) < 0) && (vz > 0) )
						objects[0].setVelocity(Vector3(vx,vy,-FILE_FS*vz));
					// + yonden - ye h�z� - ise
					if( (esitBigF(z,-443.0f-RADIUS) &&  esitBigF(-443.0f+RADIUS,z )) && ((posZ-z) > 0) && (vz < 0) )
						objects[0].setVelocity(Vector3(vx,vy,-FILE_FS*vz));
				}
				vz = objects[0].getVelocity().getZ();// get velocity z 

				if(!esitF(vx,0)){
					//std::cout <<v1.getX()<<" posx "<<posX<<" x "<<x<<" vx "<<vx<<" v3.getx "<<v3.getX()<<"\n";
					//sa�dan sol fileye
					// + yonden - ye h�z� - ise		
					if( (esitBigF(x,v3.getX()-RADIUS) && esitBigF( v3.getX()+RADIUS,x )) && ((posX-x) > 0) && (vx < 0)){
						objects[0].setVelocity(Vector3(-FILE_FS*vx,vy,vz));
						std::cout<<"a\n";
					}
					//soldan sol fileye
					// - yonden + ya h�z� + ise
					if( (esitBigF(x,v3.getX()-RADIUS) && esitBigF( v3.getX()+RADIUS,x )) && ((posX-x) < 0) && (vx > 0)){
						objects[0].setVelocity(Vector3(-FILE_FS*vx,vy,vz));
						std::cout<<"b\n";
					}
					//sa�dan sa� fileye
					// + yonden - ye h�z� - ise
					if((esitBigF(x,v1.getX()-RADIUS) && esitBigF( v1.getX()+RADIUS,x )) && ((posX-x) > 0) && (vx < 0) ){
						objects[0].setVelocity(Vector3(-FILE_FS*vx,vy,vz));
						std::cout<<"c\n";
					}
					//soldan sol fileye
					// - yonden + ya h�z� + ise
					if((esitBigF(x,v1.getX()-RADIUS) && esitBigF( v1.getX()+RADIUS,x )) && ((posX-x) < 0) && (vx > 0) ){
						objects[0].setVelocity(Vector3(-FILE_FS*vx,vy,vz));
						std::cout<<"d\n";
					}
					// - yonden + ya h�z� + ise
				}
				vx = objects[0].getVelocity().getX();// get velocity x 
				
				//	std::cout <<"vy s�f�r\n";

					if((esitBigF(y,v3.getY()-RADIUS)  && esitBigF(v3.getY()+RADIUS,y))&& ((posY-y) < 0) && (vy > 0) ){
						objects[0].setVelocity(Vector3(FILE_FS*vx,-vy,FILE_FS*vz));	
						alttan = true;
					}
					// + yonden - ye h�z� - ise
					if((esitBigF(y,v3.getY()-RADIUS)  && esitBigF(v3.getY()+RADIUS,y)) && ((posY-y) > 0) && (vy < 0) ){
						objects[0].setVelocity(Vector3(FILE_FS*vx,-vy,FILE_FS*vz));	
						vy = objects[0].getVelocity().getY();
						if( esitBigF(objects[0].getVelocity().getY() , -ZERO)  )
						{
							y= 0;
							objects[0].setPosition(Vector3(objects[0].getPosition().getX(),12+RADIUS,objects[0].getPosition().getZ()));
							objects[0].setVelocity(Vector3(FILE_FS*vx,0,FILE_FS*vz));	
						}
					}				
		}
	}


	inline bool esitBigF(float x, float y){

		float y1 = y + 0.0001f;
		float y2 = y - 0.0001f;

		return(esitF(x,y)|| (x > y) );
	}

	inline bool esitF(float x, float y){

		float y1 = y + 0.0001f;
		float y2 = y - 0.0001f;

		return(( x < y1 && x > y2) );
	}

	inline void printBall(){

		//fprintf(fp,"Ball:  %f | %f | %f \n",objects[0].getPosition().getX(),objects[0].getPosition().getY(),objects[0].getPosition().getZ());
		std::cout << "Ball: " << objects[0].getPosition().getX() << " | " << objects[0].getPosition().getY() << " | " <<
			objects[0].getPosition().getZ() << " |\n ";
		std::cout << "HIZ: " << objects[0].getVelocity().getX() << " | " << objects[0].getVelocity().getY() << " | " <<
			objects[0].getVelocity().getZ() << " |\n ";
	}

	void setStadium( float x1, float x2,float y1, float y2, float z1, float z2){

		float x,y,z,vx,vy,vz;

		x = this->getBall().getX();
		y = this->getBall().getY();
		z = this->getBall().getZ();

		vx = objects[0].getVelocity().getX();
		vy = objects[0].getVelocity().getY();
		vz = objects[0].getVelocity().getZ();

			/*std::cout <<objects[0].getPosition().getX() <<" :y "
				<<objects[0].getPosition().getY() <<" :z "
			<<objects[0].getPosition().getZ() << std::endl;
				int a;
				std::cin>> a;*/
			    // - yonden + ya h�z� + ise----------------------- Z1 ------------------------------------------
				if( (esitBigF(z,z1-RADIUS) &&  esitBigF(z1+RADIUS,z )) && ((posZ-z)<0) && (vz > 0) )
					objects[0].setVelocity(Vector3(vx,vy,-FS*vz));
				// + yonden - ye h�z� - ise
				if( (esitBigF(z,z1-RADIUS) &&  esitBigF(z1+RADIUS,z )) && ((posZ-z) > 0) && (vz < 0) )
					objects[0].setVelocity(Vector3(vx,vy,-FS*vz));
				//-------------------------------------------------- Z2 -----------------------------------
				if( (esitBigF(z,z2-RADIUS) &&  esitBigF(z2+RADIUS,z )) && ((posZ-z)<0) && (vz > 0) )
					objects[0].setVelocity(Vector3(vx,vy,-FS*vz));
				// + yonden - ye h�z� - ise
				if( (esitBigF(z,z2-RADIUS) &&  esitBigF(z2+RADIUS,z )) && ((posZ-z) > 0) && (vz < 0) )
					objects[0].setVelocity(Vector3(vx,vy,-FS*vz));
				vz = objects[0].getVelocity().getZ();// get velocity z 
				//--------------------------------------------------X1 -----------------------------------
				// + yonden - ye h�z� - ise		
				if( (esitBigF(x,x1-RADIUS) && esitBigF( x1+RADIUS,x )) && ((posX-x) > 0) && (vx < 0))
					objects[0].setVelocity(Vector3(-FS*vx,vy,vz));
				// - yonden + ya h�z� + ise
				if( (esitBigF(x,x1-RADIUS) && esitBigF( x1+RADIUS,x )) && ((posX-x) < 0) && (vx > 0))
					objects[0].setVelocity(Vector3(-FS*vx,vy,vz));
				//--------------------------------------------------X2 -----------------------------------
				// + yonden - ye h�z� - ise
				if((esitBigF(x,x2-RADIUS) && esitBigF( x2+RADIUS,x )) && ((posX-x) > 0) && (vx < 0) )
					objects[0].setVelocity(Vector3(-FS*vx,vy,vz));
				// - yonden + ya h�z� + ise
				if((esitBigF(x,x2-RADIUS) && esitBigF( x2+RADIUS,x )) && ((posX-x) < 0) && (vx > 0) )
					objects[0].setVelocity(Vector3(-FS*vx,vy,vz));
				// - yonden + ya h�z� + ise
				vx = objects[0].getVelocity().getX();// get velocity x 
				/*--------------------------------------------- Y1 -----------------------------*/
				if((y1-RADIUS <= y && y <= y1+RADIUS) && ((posY-y) < 0) && (vy > 0) )
					objects[0].setVelocity(Vector3(vx,-vy,vz));	
				// + yonden - ye h�z� - ise
				if((y1-RADIUS <= y && y <= y1+RADIUS) && ((posY-y) > 0) && (vy < 0) )
					objects[0].setVelocity(Vector3(vx,-vy,vz));	
				//-------------------------------------------- Y2 -----------------------------------
				if((y2-RADIUS <= y && y <= y2+RADIUS) && ((posY-y) < 0) && (vy > 0) )
					objects[0].setVelocity(Vector3(vx,-vy,vz));	
				// + yonden - ye h�z� - ise
				if((y2-RADIUS <= y && y <= y2+RADIUS) && ((posY-y) > 0) && (vy < 0) )
					objects[0].setVelocity(Vector3(vx,-vy,vz));	
	
	}


	bool leftVibrate,alttan;
	bool rightVibrate;
	Vector3 v1,v3;
	float posX, posY, posZ; // old positions.
	bool handle;
	float duzlem;
	FILE *fp;
	std::vector<PhysicObj> objects;
};
#endif