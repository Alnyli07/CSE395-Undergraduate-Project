#ifndef MYSOCKET
#define MYSOCKET
#ifdef __linux__
#include <stdio.h>

#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

class mySocket{
public:
	mySocket(char *ip, int port){
		struct sockaddr_in server;
		//Create socket
		sock = socket(AF_INET, SOCK_STREAM, 0);
		if (sock == -1)
		{
			printf("Could not create socket");
		}
		puts("Socket created");

		server.sin_addr.s_addr = inet_addr(ip);
		server.sin_family = AF_INET;
		server.sin_port = htons(port);

		//Connect to remote server
		if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0)
		{
			perror("connect failed. Error");
		}
	}

	int ReadString(char *str, char FinalChar, unsigned int MaxNbBytes)
		{
			int i;
			int j;
			bufLen = recv(sock , str , MaxNBytes - bufLen , 0) + bufLen;
			buf[bufLen] = '\0';
			for (i = 0; i < bufLen && buf[i] != '\0' && buf[i] != FinalChar; i++){

				str[i] = buf[i];
		}
			str[i] = buf[i];
			str[i + 1] = '\0';
			printf("sitring: %s\n", str);
			if (str[i] == FinalChar){
				for (j = i + 1; buf[j] != '\0'; j++)
					buf[j - i - 1] = buf[j];
				bufLen -= i + 1;
				buf[j] = '\0';
				return 5;
			}
			return 0;
	}
	char WriteChar(char a)
	{
		send(sock , &a , 1 , 0);
		return 'a';
	}
	~mySocket(){
		close(sock);
	}
private:
	int soc;
	char buf[4096];
	int bufLen = 0;
};

#endif
#endif