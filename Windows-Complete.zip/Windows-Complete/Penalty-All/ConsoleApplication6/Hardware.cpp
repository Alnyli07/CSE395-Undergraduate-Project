#include "Hardware.h"

#if defined (_WIN32) || defined( _WIN64)
#define COMNAME "COM"
#endif

hardware::hardware(){
	#if defined (_WIN32) || defined( _WIN64)
	xDir=0;
	#endif
	exit = false;
	isBallHit=false;
	rHandArmDirection[0]=0;
	rHandArmDirection[1]=0;
	rHandArmDirection[2]=0;
	rHandShoulderDirection[0]=0;
	rHandShoulderDirection[1]=0;
	rHandShoulderDirection[2]=0;
	
	lHandArmDirection[0]=0;
	lHandArmDirection[1]=0;
	lHandArmDirection[2]=0;
	lHandShoulderDirection[0]=0;
	lHandShoulderDirection[1]=0;
	lHandShoulderDirection[2]=0;
}
#if defined (_WIN32) || defined( _WIN64)
void hardware::lockBall(){
	WaitForSingleObject(ballSemaphore, INFINITE);
}
void hardware::unlockBall(){
	ReleaseSemaphore(ballSemaphore, 1, NULL);
}
void hardware::lockRHand(){
	WaitForSingleObject(rHandSemaphore, INFINITE);
}
void hardware::unlockRHand(){
	ReleaseSemaphore(rHandSemaphore, 1, NULL);
}
void hardware::lockLHand(){
	WaitForSingleObject(lHandSemaphore, INFINITE);
}
void hardware::unlockLHand(){
	ReleaseSemaphore(lHandSemaphore, 1, NULL);
}
#else
void hardware::lockSocket(){
	sem_wait(&socketSemaphore);
}
void hardware::unlockSocket(){
	sem_post(&socketSemaphore);
}
#endif
int hardware::startHardware(char *ip, int port){
#if defined (_WIN32) || defined( _WIN64)
	int Ret;
	char Buffer[128], comAddr[15];
	bool isBallConnected = false, isRHandConnected = false, isLHandConnected = false;
	ballSemaphore = CreateSemaphore(NULL, 1, 1, NULL);
	rHandSemaphore = CreateSemaphore(NULL, 1, 1, NULL);
	lHandSemaphore = CreateSemaphore(NULL, 1, 1, NULL);
	for (int i = 1; i < 25 && (!isBallConnected || !isLHandConnected || !isRHandConnected); i++){
		serialib com;
		sprintf_s(comAddr, "%s%d", COMNAME, i);
		Ret = com.Open(comAddr, 115200);
		printf("%s %d\n", comAddr, Ret);
		Sleep(80);
		if (Ret == 1){
			Ret = com.ReadString(Buffer, '\n', 128, 1000);
			if (Ret>0)
				Ret = com.ReadString(Buffer, '\n', 128, 1000);
			//printf(Buffer);
			if (Ret > 0){
				if ((strncmp("pb ", Buffer, 3) == 0) && !isBallConnected){
					printf("Ball connected\n");
					isBallConnected = true;
					ball = com;
					ballThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)calculateBall, this, 0, NULL);
				}
				else if ((strncmp("lh ", Buffer, 3) == 0) && !isLHandConnected){
					printf("lHand connected\n");
					isLHandConnected = true;
					lHand = com;
					lHandThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)calculateLHand, this, 0, NULL);
				}

				else if ((strncmp("rh ", Buffer, 3) == 0) && !isRHandConnected){
					printf("rHand connected\n");
					isRHandConnected = true;
					rHand = com;
					rHandThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)calculateRHand, this, 0, NULL);
				}
				else
					com.Close();
			}
		}
	}
	if (!isRHandConnected || !isLHandConnected || !isBallConnected)
		return -1;
	return 0;
#else
	sem_init(&socketSemaphore, 0, 1);
	socket = mySocket(ip, port);
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	pthread_create(&socketThread, &attr, connectSocket, this);
	pthread_attr_destroy(&attr);
	return 0;
#endif
}
bool hardware::getIsBallHit(){

	return isBallHit;
	//return true;
}
void hardware::resetHardware(){
#if defined (_WIN32) || defined( _WIN64)
	resetBall();
	resetRHand();
	resetLHand();
#else
	lockSocket();
	socket.writeChar('s');
	unlockSocket();
#endif
}
#if defined (_WIN32) || defined( _WIN64)
void hardware::resetBall(){
	char Buffer[128];
	int Ret, ax, ay, az, gx, gy, gz, time;
	lockBall();
	xDir = 0;
	isBallHit = false;
	ballDirection[0] = 0;
	ballDirection[1] = 0;
	ballDirection[2] = 0;
	ballVelocity[0] = 0;
	ballVelocity[1] = 0;
	ballVelocity[2] = 0;
	ballaRefs[0] = 0;
	ballaRefs[1] = 0;
	ballaRefs[2] = 0;
	ballgRefs[0] = 0;
	ballgRefs[1] = 0;
	ballgRefs[2] = 0;
	for (int i = 0; i < 10; i++)
	{
		Sleep(15);
		Ret = ball.ReadString(Buffer, '\n', 128, 1000);
	//	printf("%s\n", Buffer);
		if (Ret > 0){
			sscanf_s(&Buffer[3], "%d %d %d %d %d %d %d", &time, &ax, &ay, &az, &gx, &gy, &gz);

		}
		ballaRefs[0] += ax;
		ballaRefs[1] += ay;
		ballaRefs[2] += az;
		ballgRefs[0] += gx;
		ballgRefs[1] += gy;
		ballgRefs[2] += gz;
	}
	ballaRefs[0] /= 10;
	ballaRefs[1] /= 10;
	ballaRefs[2] /= 10;
	ballgRefs[0] /= 10;
	ballgRefs[1] /= 10;
	ballgRefs[2] /= 10;

	ballaRefs[0] = (ballaRefs[0] / 32767.0) * ACCELRANGE * GRAVITY;
	ballaRefs[1] = (ballaRefs[1] / 32767.0) * ACCELRANGE * GRAVITY;
	ballaRefs[2] = (ballaRefs[2] / 32767.0) * ACCELRANGE * GRAVITY;
	unlockBall();
}
void hardware::resetRHand(){
	char Buffer[128];
	int Ret, ax, ay, az, gx, gy, gz, time;
	lockRHand();
	rHandShoulderDirection[0] = 0;
	rHandShoulderDirection[1] = 0;
	rHandShoulderDirection[2] = 0;
	rHandArmDirection[0] = 0;
	rHandArmDirection[1] = 0;
	rHandArmDirection[2] = 0;
	rHandgRefs[0] = 0;
	rHandgRefs[1] = 0;
	rHandgRefs[2] = 0;
	rHandgRefs[3] = 0;
	rHandgRefs[4] = 0;
	rHandgRefs[5] = 0;
	for (int i = 0; i < 10; i++)
	{
		Sleep(15);
		Ret = rHand.ReadString(Buffer, '\n', 128, 1000);
		if (Ret > 0){
			sscanf_s(&Buffer[3], "%d %d %d %d %d %d %d", &time, &ax, &ay, &az, &gx, &gy, &gz);

		}
		rHandgRefs[0] += ax;
		rHandgRefs[1] += ay;
		rHandgRefs[2] += az;
		rHandgRefs[3] += gx;
		rHandgRefs[4] += gy;
		rHandgRefs[5] += gz;
	}
	rHandgRefs[0] /= 10;
	rHandgRefs[1] /= 10;
	rHandgRefs[2] /= 10;
	rHandgRefs[3] /= 10;
	rHandgRefs[4] /= 10;
	rHandgRefs[5] /= 10;

	unlockRHand();
}
void hardware::resetLHand(){
	char Buffer[128];
	int Ret, ax, ay, az, gx, gy, gz, time;
	lockLHand();
	lHandShoulderDirection[0] = 0;
	lHandShoulderDirection[1] = 0;
	lHandShoulderDirection[2] = 0;
	lHandArmDirection[0] = 0;
	lHandArmDirection[1] = 0;
	lHandArmDirection[2] = 0;
	lHandgRefs[0] = 0;
	lHandgRefs[1] = 0;
	lHandgRefs[2] = 0;
	lHandgRefs[3] = 0;
	lHandgRefs[4] = 0;
	lHandgRefs[5] = 0;
	for (int i = 0; i < 10; i++)
	{
		Sleep(15);
		Ret = lHand.ReadString(Buffer, '\n', 128, 1000);
		if (Ret > 0){
			sscanf_s(&Buffer[3], "%d %d %d %d %d %d %d", &time, &ax, &ay, &az, &gx, &gy, &gz);

		}
		lHandgRefs[0] += ax;
		lHandgRefs[1] += ay;
		lHandgRefs[2] += az;
		lHandgRefs[3] += gx;
		lHandgRefs[4] += gy;
		lHandgRefs[5] += gz;
	}
	lHandgRefs[0] /= 10;
	lHandgRefs[1] /= 10;
	lHandgRefs[2] /= 10;
	lHandgRefs[3] /= 10;
	lHandgRefs[4] /= 10;
	lHandgRefs[5] /= 10;

	unlockLHand();
}
#endif
Vector3 hardware::getBallDirection(){
#if defined (_WIN32) || defined( _WIN64)
	lockBall();
#else
	lockSocket();
#endif
	Vector3 v(ballDirection[0], ballDirection[1], ballDirection[2]);
#if defined (_WIN32) || defined( _WIN64)
	unlockBall();
#else
	unlockSocket();
#endif
	return v;
}
Vector3 hardware::getBallVelocity(){
#if defined (_WIN32) || defined( _WIN64)
	lockBall();
#else
	lockSocket();
#endif
	if(ballVelocity[0]>=5)
		ballVelocity[0]=5;
	if(ballVelocity[0]<=-5)
		ballVelocity[0]=-5;
	Vector3 v(-ballVelocity[1] * 10, -ballVelocity[2] * 13, -ballVelocity[0] * 13);
	

#if defined (_WIN32) || defined( _WIN64)
	unlockBall();
#else
	unlockSocket();
#endif
	return v;
}

Vector3 hardware::getRHandShoulderDirection(){
#if defined (_WIN32) || defined( _WIN64)
	lockRHand();
#else
	lockSocket();
#endif
	Vector3 v(rHandShoulderDirection[0], rHandShoulderDirection[1], rHandShoulderDirection[2]);
#if defined (_WIN32) || defined( _WIN64)
	unlockRHand();
#else
	unlockSocket();
#endif
	return v;
}
Vector3 hardware::getLHandShoulderDirection(){
#if defined (_WIN32) || defined( _WIN64)
	lockLHand();
#else
	lockSocket();
#endif
	Vector3 v(lHandShoulderDirection[0], lHandShoulderDirection[1], lHandShoulderDirection[2]);
#if defined (_WIN32) || defined( _WIN64)
	unlockLHand();
#else
	unlockSocket();
#endif
	return v;
}
Vector3 hardware::getRHandArmDirection(){
#if defined (_WIN32) || defined( _WIN64)
	lockRHand();
#else
	lockSocket();
#endif
	Vector3 v(rHandArmDirection[0], rHandArmDirection[1], rHandArmDirection[2]);
#if defined (_WIN32) || defined( _WIN64)
	unlockRHand();
#else
	unlockSocket();
#endif
	return v;
}
Vector3 hardware::getLHandArmDirection(){
#if defined (_WIN32) || defined( _WIN64)
	lockLHand();
#else
	lockSocket();
#endif
	Vector3 v(lHandArmDirection[0], lHandArmDirection[1], lHandArmDirection[2]);
#if defined (_WIN32) || defined( _WIN64)
	unlockLHand();
#else
	unlockSocket();
#endif
	return v;
}
Vector3 hardware::getRHandLocation(){
	double shoulder[3] = { 6, 0, 0 }, arm[3] = { 6, 0, 0 };
#if defined (_WIN32) || defined( _WIN64)
	lockRHand();
#else
	lockSocket();
#endif
	Quaternion<double> sh(rHandShoulderDirection, EulOrdXYZr), ar(rHandArmDirection, EulOrdXYZr);
#if defined (_WIN32) || defined( _WIN64)
	unlockRHand();
#else
	unlockSocket();
#endif
	//printf("%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f\n", rHandShoulderDirection[0], rHandShoulderDirection[1], rHandShoulderDirection[2], rHandArmDirection[0], rHandArmDirection[1], rHandArmDirection[2]);
	sh.QuatRotation(shoulder);
	ar.QuatRotation(arm);
	return Vector3(-3 * (shoulder[1] + arm[1]) + 155, -(shoulder[0] + arm[0]) + 6, - 456);
}
Vector3 hardware::getLHandLocation(){
	double shoulder[3] = { 6, 0, 0 }, arm[3] = { 6, 0, 0 };
#if defined (_WIN32) || defined( _WIN64)
	lockLHand();
#else
	lockSocket();
#endif
	Quaternion<double> sh(lHandShoulderDirection, EulOrdXYZr), ar(lHandArmDirection, EulOrdXYZr);
#if defined (_WIN32) || defined( _WIN64)
	unlockLHand();
#else
	unlockSocket();
#endif
	
	sh.QuatRotation(shoulder);
	ar.QuatRotation(arm);
	return Vector3(-3 * (shoulder[1] + arm[1]) + 140, -(shoulder[0] + arm[0]) + 6, -456);
}

double f(double r){
	if (r < - PI)
		return r + 2 * PI;
	if (r > PI)
		return r - 2 * PI;
	return r;
}
#if defined (_WIN32) || defined( _WIN64)
void hardware::calculateBall(void *a){
	char Buffer[128];
	int ax, ay, az, gx, gy, gz, time;
	double accVec[3];
	hardware *h = (hardware *)a;

	while (1){
		h->lockBall();
		
		if (h->ball.ReadString(Buffer, '\n', 128, 100) > 0){
			sscanf_s(&Buffer[3], "%d %d %d %d %d %d %d", &time, &ax, &ay, &az, &gx, &gy, &gz);

			//printf(Buffer);
			gx -= h->ballgRefs[0];
			gy -= h->ballgRefs[1];
			gz -= h->ballgRefs[2];
			double tgx = ((gx) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgy = ((gy) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgz = ((gz) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0);
			//printf("%10f%10f%10f\n", tgx, tgy, tgz);
			if ((tgx > 0.0009 || tgx< -0.0009))
				h->ballDirection[0] += tgx;
			if (tgy>0.0009 || tgy< -0.0009)
				h->ballDirection[1] += tgy;
			if (tgz>0.0009 || tgz < -0.0009)
				h->ballDirection[2] += tgz;

			h->ballDirection[0] = f(h->ballDirection[0]);
			h->ballDirection[1] = f(h->ballDirection[1]);
			h->ballDirection[2] = f(h->ballDirection[2]);
			accVec[0] = (ax / 32767.0) * ACCELRANGE * GRAVITY;
			accVec[1] = (ay / 32767.0) * ACCELRANGE * GRAVITY;
			accVec[2] = (az / 32767.0) * ACCELRANGE * GRAVITY;
			Quaternion<double> q(h->ballDirection, EulOrdXYZr);
			q.QuatRotation(accVec);
			accVec[0] -= h->ballaRefs[0];
			accVec[1] -= h->ballaRefs[1];
			accVec[2] -= h->ballaRefs[2];
			if ((h->xDir == 0 || (accVec[0] * h->xDir > 0)) && (!h->isBallHit)){
				if (accVec[0] > 3 || accVec[0] < -3){
					if (h->xDir == 0)
						if (accVec[0] > 0 && h->ballVelocity[0] > 1)
							h->xDir = 1;
						else if (h->ballVelocity[0]<-1)
							h->xDir = -1;
					h->ballVelocity[0] += accVec[0] * (time / 1000.0);
				}
				if (accVec[1] > 1.5 || accVec[1] < -1.5)
					h->ballVelocity[1] += accVec[1] * (time / 1000.0);
				if (accVec[2]>1.5 || accVec[2] < -1.5)
					h->ballVelocity[2] += accVec[2] * (time / 1000.0);

			}
			else
				h->isBallHit = true;
		}
		else
			printf("Ball Error");
		
		//printf("%2d%10f%10f%10f%10f%10f%10f\n", h->xDir, h->ballVelocity[0], h->ballVelocity[1], h->ballVelocity[2], h->ballDirection[0], h->ballDirection[1], h->ballDirection[2]);
		h->unlockBall();
		if (h->exit){
			return;
		}
	}
}
void hardware::calculateRHand(void *a){
	char Buffer[128];
	int gx, gy, gz, gx2, gy2, gz2, time;
	hardware *h = (hardware *)a;
	while (1){
		h->lockRHand();
		
		if (h->rHand.ReadString(Buffer, '\n', 128, 100) > 0){
			sscanf_s(&Buffer[3], "%d %d %d %d %d %d %d", &time, &gx, &gy, &gz, &gx2, &gy2, &gz2);
			//printf(Buffer);
			gx -= h->rHandgRefs[0];
			gy -= h->rHandgRefs[1];
			gz -= h->rHandgRefs[2];
			gx2 -= h->rHandgRefs[3];
			gy2 -= h->rHandgRefs[4];
			gz2 -= h->rHandgRefs[5];
			double tgx = ((gx) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgy = ((gy) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgz = ((gz) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgx2 = ((gx2) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgy2 = ((gy2) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgz2 = ((gz2) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0);
			if ((tgx > 0.000 || tgx< -0.000))
				h->rHandShoulderDirection[0] += tgx;
			if (tgy>0.000 || tgy< -0.000)
				h->rHandShoulderDirection[1] += tgy;
			if (tgz>0.000 || tgz < -0.000)
				h->rHandShoulderDirection[2] += tgz;
			if ((tgx2 > 0.000 || tgx2< -0.000))
				h->rHandArmDirection[0] += tgx2;
			if (tgy2>0.000 || tgy2< -0.000)
				h->rHandArmDirection[1] += tgy2;
			if (tgz2>0.000 || tgz2 < -0.000)
				h->rHandArmDirection[2] += tgz2;
			h->rHandShoulderDirection[0] = f(h->rHandShoulderDirection[0]);
			h->rHandShoulderDirection[1] = f(h->rHandShoulderDirection[1]);
			h->rHandShoulderDirection[2] = f(h->rHandShoulderDirection[2]);
			h->rHandArmDirection[0] = f(h->rHandArmDirection[0]);
			h->rHandArmDirection[1] = f(h->rHandArmDirection[1]);
			h->rHandArmDirection[2] = f(h->rHandArmDirection[2]);
		}
		else
			printf("RHand Error");
		h->unlockRHand();
		if (h->exit){
			return;
		}
	}
}
void hardware::calculateLHand(void *a){
	char Buffer[128];
	int gx, gy, gz, gx2, gy2, gz2, time;
	hardware *h = (hardware *)a;
	while (1){
		h->lockLHand();
		
		if (h->lHand.ReadString(Buffer, '\n', 128, 100) > 0){
			sscanf_s(&Buffer[3], "%d %d %d %d %d %d %d", &time, &gx, &gy, &gz, &gx2, &gy2, &gz2);
			//printf(Buffer);
			gx -= h->lHandgRefs[0];
			gy -= h->lHandgRefs[1];
			gz -= h->lHandgRefs[2];
			gx2 -= h->lHandgRefs[3];
			gy2 -= h->lHandgRefs[4];
			gz2 -= h->lHandgRefs[5];
			double tgx = ((gx) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgy = ((gy) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgz = ((gz) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgx2 = ((gx2) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgy2 = ((gy2) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0),
				tgz2 = ((gz2) / 32767.0) * GYRORANGE * (PI / 180) * (time / 1000.0);
			if ((tgx > 0.000 || tgx< -0.000))
				h->lHandShoulderDirection[0] += tgx;
			if (tgy>0.000 || tgy< -0.000)
				h->lHandShoulderDirection[1] += tgy;
			if (tgz>0.000 || tgz < -0.001)
				h->lHandShoulderDirection[2] += tgz;
			if ((tgx2 > 0.000 || tgx2< -0.000))
				h->lHandArmDirection[0] += tgx2;
			if (tgy2>0.000 || tgy2< -0.000)
				h->lHandArmDirection[1] += tgy2;
			if (tgz2>0.000 || tgz2 < -0.000)
				h->lHandArmDirection[2] += tgz2;
			h->lHandShoulderDirection[0] = f(h->lHandShoulderDirection[0]);
			h->lHandShoulderDirection[1] = f(h->lHandShoulderDirection[1]);
			h->lHandShoulderDirection[2] = f(h->lHandShoulderDirection[2]);
			h->lHandArmDirection[0] = f(h->lHandArmDirection[0]);
			h->lHandArmDirection[1] = f(h->lHandArmDirection[1]);
			h->lHandArmDirection[2] = f(h->lHandArmDirection[2]);
		}
		else
			printf("LHand Error");
		h->unlockLHand();
		if (h->exit){
			return;
		}
	}
}
#else
void* hardware::connectSocket(void *a){
	hardware *h = (hardware *)a;
	int b;
	char str[512];
	while(1){
		h->lockSocket();
		if(h->socket.ReadString(str,'\n',512)){
			sscanf(str,"%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %d",
				&(h->ballVelocity[0]),&(h->ballVelocity[1]),&(h->ballVelocity[2]),&(h->ballDirection[0]),&(h->ballDirection[1]),&(h->ballDirection[2]),
				&(h->rHandShoulderDirection[0]),&(h->rHandShoulderDirection[1]),&(h->rHandShoulderDirection[2]),&(h->rHandArmDirection[0]),&(h->rHandArmDirection[1]),&(h->rHandArmDirection[2]),
				&(h->lHandShoulderDirection[0]),&(h->lHandShoulderDirection[1]),&(h->lHandShoulderDirection[2]),&(h->lHandArmDirection[0]),&(h->lHandArmDirection[1]),&(h->lHandArmDirection[2]),
				&b);
		}
		h->unlockSocket();
		if(h->exit)
			return NULL;
	}
}
#endif
void hardware::vibrateRHand(){
#if defined (_WIN32) || defined( _WIN64)
	lockRHand();
	rHand.WriteString("aaaaa");
	unlockRHand();
#else
	lockSocket();
	socket.writeChar('r');
	unlockSocket();
#endif	
}

void hardware::vibrateLHand(){
#if defined (_WIN32) || defined( _WIN64)
	lockLHand();
	lHand.WriteString("aaaaa");
	unlockLHand();
#else
	lockSocket();
	socket.writeChar('l');
	unlockSocket();
#endif	
}
int hardware::endHardware(){
#if defined (_WIN32) || defined( _WIN64)
	lockBall();
	lockRHand();
	lockLHand();
	exit = true;
	unlockBall();
	unlockRHand();
	unlockLHand();
	WaitForSingleObject(ballThread, INFINITE);
	WaitForSingleObject(lHandThread, INFINITE);
	WaitForSingleObject(rHandThread, INFINITE);
	CloseHandle(ballThread);
	CloseHandle(lHandThread);
	CloseHandle(rHandThread);
	CloseHandle(ballSemaphore);
	CloseHandle(rHandSemaphore);
	CloseHandle(lHandSemaphore);
	ball.Close();
	rHand.Close();
	lHand.Close();
#else
	lockSocket();
	exit=true;
	unlockSocket();
	pthread_join(socketThread, NULL);
	sem_destroy(&socketSemaphore);
	socket.Close();
#endif
	return 0;
}