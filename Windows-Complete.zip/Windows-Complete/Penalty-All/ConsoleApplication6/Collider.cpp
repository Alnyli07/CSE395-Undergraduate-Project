
#include "Collider.h"
#include "Ball.h"

Collision Collider::collision(const Collider& other) const
	{
		if(type == TYPE_BALL && other.getType() == TYPE_BALL)
		{
			Ball* ball = (Ball*)this;
			return ball->collisionBall((Ball&)other);
		}

		//Control should never reach this point
		return Collision(false, 0);
	}