/*cse 395 project group 1 */

#include <irrlicht.h>
#include "driverChoice.h"
#include <math.h>
#include <vector3d.h>
#include "PhysicEngine.h"
#include "Ball.h"
#include "gameEngine.h"
#include "driverChoice.h"
#include "Hardware.h"
#include <SFML/Audio.hpp>

#define UPDATE 0.033f



#ifdef _MSC_VER
#pragma comment(lib, "Irrlicht.lib")
#endif

//Namespaces for the engine
using namespace irr;
using namespace core;
using namespace video;
using namespace scene;
using namespace gui;
using namespace io;
/*
/*
Now we'll define the resolution in a constant for use in
initializing the device and setting up the viewport. In addition
we set up a global variable saying splitscreen is active or not.
*/
//Resolution
const int ResX = 1366;
const int ResY = 768;
const bool fullScreen = false;

//Use SplitScreen?
bool SplitScreen = true;

//struct SAppContext
//{
//	IrrlichtDevice *device;
//	s32				counter;
//	IGUIListBox*	listbox;
//};

// Define some values that we'll use to identify individual GUI controls.
enum
{
	GUI_ID_QUIT_BUTTON = 101,
	GUI_ID_NEW_GAME,
	GUI_ID_POSITION_TEXT,
};

/*
	Set the skin transparency by changing the alpha values of all skin-colors
*/

hardware hard;
int isEnter = 0;
bool isDebugMode = false;

/*
Now we need four pointers to our cameras which are created later:
*/
//cameras
ICameraSceneNode *camera[2] = { 0, 0 };
/*
In our event-receiver we switch the SplitScreen-variable,
whenever the user press the S-key. All other events are sent
to the FPS camera.
*/

class MyEventReceiver : public IEventReceiver
{
public:
	
	virtual bool OnEvent(const SEvent& event)
	{
		//Key S enables/disables SplitScreen
		if (event.EventType == irr::EET_KEY_INPUT_EVENT &&
			event.KeyInput.Key == KEY_KEY_S && event.KeyInput.PressedDown)
		{
			SplitScreen = !SplitScreen;
			return true;
		}
		if (event.EventType == irr::EET_KEY_INPUT_EVENT &&
			event.KeyInput.Key == KEY_ESCAPE)
		{
			hard.endHardware();
			exit(0);
		}
		
		if(event.EventType == irr::EET_KEY_INPUT_EVENT && 
			event.KeyInput.Key == KEY_RETURN)
		{
			isEnter = 1;
		}
		if(event.EventType == irr::EET_KEY_INPUT_EVENT &&
			event.KeyInput.Key == KEY_KEY_D)
		{
			isDebugMode = true;
		}
		//Send all other events to camera4
		if (camera[1])
			return camera[1]->OnEvent(event);
		return false;
	}
};


const int DELAY_TIME = 3000;

enum ETimerAction
{
	ETA_MOUSE_VISIBLE,
	ETA_MOUSE_INVISIBLE,
};

/*
	Structure to allow delayed execution of some actions.
*/
struct TimerAction
{
	u32 TargetTime;
	ETimerAction Action;
};

/*
*/
struct SAppContext
{
	SAppContext()
	: Device(0), InfoStatic(0), EventBox(0), CursorBox(0), SpriteBox(0)
	, ButtonSetVisible(0), ButtonSetInvisible(0), ButtonSimulateBadFps(0)
	, ButtonChangeIcon(0)
	, SimulateBadFps(false)
	{
	}

	void update()
	{
		if (!Device)
			return;
		u32 timeNow = Device->getTimer()->getTime();
		for ( u32 i=0; i < TimerActions.size(); ++i )
		{
			if ( timeNow >= TimerActions[i].TargetTime )
			{
				runTimerAction(TimerActions[i]);
				TimerActions.erase(i);
			}
			else
			{
				++i;
			}
		}
	}

	void runTimerAction(const TimerAction& action)
	{
		if (ETA_MOUSE_VISIBLE == action.Action)
		{
			Device->getCursorControl()->setVisible(true);
			ButtonSetVisible->setEnabled(true);
		}
		else if ( ETA_MOUSE_INVISIBLE == action.Action)
		{
			Device->getCursorControl()->setVisible(false);
			ButtonSetInvisible->setEnabled(true);
		}
	}

	/*
		Add another icon which the user can click and select as cursor later on.
	*/
	void addIcon(const stringw& name, const SCursorSprite &sprite, bool addCursor=true)
	{
		// Sprites are just icons - not yet cursors. They can be displayed by Irrlicht sprite functions and be used to create cursors.
		SpriteBox->addItem(name.c_str(), sprite.SpriteId);
		Sprites.push_back(sprite);

		// create the cursor together with the icon?
		if ( addCursor )
		{
			/* Here we create a hardware cursor from a sprite */
			Device->getCursorControl()->addIcon(sprite);

			// ... and add it to the cursors selection listbox to the other system cursors.
			CursorBox->addItem(name.c_str());
		}
	}

	IrrlichtDevice * Device;
	gui::IGUIStaticText * InfoStatic;
	gui::IGUIListBox * EventBox;
	gui::IGUIListBox * CursorBox;
	gui::IGUIListBox * SpriteBox;
	gui::IGUIButton * ButtonSetVisible;
	gui::IGUIButton * ButtonSetInvisible;
	gui::IGUIButton * ButtonSimulateBadFps;
	gui::IGUIButton * ButtonChangeIcon;
	array<TimerAction> TimerActions;
	bool SimulateBadFps;
	array<SCursorSprite> Sprites;
};

class MyEventReceiverGui : public IEventReceiver
{
public:
	MyEventReceiverGui(SAppContext & context) : Context(context) { }

	virtual bool OnEvent(const SEvent& event)
	{
		
		if (event.EventType == EET_GUI_EVENT)
		{
			s32 id = event.GUIEvent.Caller->getID();
			IGUIEnvironment* env = Context.Device->getGUIEnvironment();

			switch(event.GUIEvent.EventType)
			{
			case EGET_BUTTON_CLICKED:
				switch(id)
				{
				case GUI_ID_QUIT_BUTTON:
					Context.Device->closeDevice();
					return true;

				case GUI_ID_NEW_GAME:
					{					
						gameEngine game,game1,game2,game3,game4;
						PhysicEngine p;
						int counter = 0;
						// ask user for driver
						video::E_DRIVER_TYPE driverType = EDT_OPENGL;
						if (driverType == video::EDT_COUNT)
							return 1;
						
							// for tribune sound
							sf::SoundBuffer buffer;
							if (!buffer.loadFromFile("../media/tribun.wav"))
								return false;
							sf::Sound sound;
							sound.setBuffer(buffer);
							sound.play();
							sound.setLoop(true);

							// for goal sound
							sf::SoundBuffer buffer_goal;
							if (!buffer_goal.loadFromFile("../media/goal.wav"))
									return false;
							sf::Sound sound_goal;
							sound_goal.setBuffer(buffer_goal);
	
							// if it is not goal sound
							sf::SoundBuffer buffer_Notgoal;
							if (!buffer_Notgoal.loadFromFile("../media/noGoal.wav"))
									return false;
							sf::Sound sound_Notgoal;
							sound_Notgoal.setBuffer(buffer_Notgoal);

						//Instance of the EventReceiver
						MyEventReceiver receiver;

						//Initialise the engine
						IrrlichtDevice *device = createDevice(driverType,
							dimension2du(ResX, ResY), 32, fullScreen,
							false, false, &receiver);
						if (!device)
							return 1;
						
						ISceneManager *smgr = device->getSceneManager();
						IVideoDriver *driver = device->getVideoDriver();
						gui::IGUIEnvironment* env_2 = device->getGUIEnvironment();
						IGUISkin* skin = env_2->getSkin();
						IGUIFont* font = env_2->getFont("../media/font2.png");

						smgr->addLightSceneNode(0, core::vector3df(200,200,200),
						video::SColorf(1.0f,1.0f,1.0f),2000);
						smgr->setAmbientLight(video::SColorf(0.3f,0.3f,0.3f));
						s32 score = 15; 
						gui::IGUIListBox * EventBox;
						
						rect< s32 > rectEventBox(0,0, 800, 800);
						Context.EventBox = env_2->addListBox(rectEventBox);
						
						Context.InfoStatic = env_2->addStaticText (L"", rectEventBox, true, true);
						/*stringw infoText;
						infoText += stringw(L"llalalalal = ");*/
						//infoText = L"cvhjklkjhgffgh";
				
						/*Context.InfoStatic = env_2->addStaticText (L"", rectInfoStatic, true, true);
 						Context.InfoStatic->setText(infoText.c_str());
						Context.EventBox->insertItem(0, infoText.c_str(), -1);*/

						if (font)
							skin->setFont(font);

						skin->setFont(env->getBuiltInFont(), EGDF_TOOLTIP);
						//env_2->getSkin()->setFont(env->getFont("../media/fontlucida.png"));
						/*IGUIStaticText* debugText = env->addStaticText(L"dsads",
								core::rect<s32>(10,421,450,475),true, true, 0, -1, true);*/
				
						/*env_2->addStaticText(L"lalalal",
							core::rect<s32>(ResX-10,0,ResX,200), true, true, 0, -1, true);*/
						//Load model
						IAnimatedMesh *model = smgr->getMesh("../media/saha.obj");
						if (!model)
							return 1;
						IAnimatedMeshSceneNode *model_node = smgr->addAnimatedMeshSceneNode(model);
						//Load texture
						if (model_node)
						{
							//ITexture *texture = driver->getTexture("../../media/sydney.bmp");
							//model_node->setMaterialTexture(0, texture);
							model_node->setMD2Animation(scene::EMAT_RUN);
							//Disable lighting (we've got no light)
							model_node->setMaterialFlag(EMF_LIGHTING, false);
							model_node->setScale(model_node->getScale() * 5);
						}
						
	//		

						float x =512;//509;
						float y =RADIUS;
						float z = -150.f;
						hard.resetBall();
						hard.resetRHand();
						hard.resetLHand();
						
						Vector3 a(0.f,0.f,0.f);//-z,y,-x
						p.setDuzlem(RADIUS);
						game.setPosition(Vector3(x,y,z));
						game1.setPosition(a);
						game4.setPosition(Vector3(456,8,-138));// SOL ELDIVEN
						game3.setPosition(Vector3(456,8,-158));// SAG ELDIVEN
						PhysicObj o1(new Ball(game.getPosition(),RADIUS),game1.getPosition(), true);
						p.addObject(o1);
						PhysicObj o2(new Ball(game4.getPosition(),2*RADIUS),game1.getPosition(), false);
						p.addObject(o2);
						PhysicObj o3(new Ball(game3.getPosition(),2*RADIUS),game1.getPosition(), false);
						p.addObject(o3);
						//game4.setPosition(Vector3(-1,-5,-1));
						//PhysicObj o2(new Ball(game4.getPosition(), RADIUS),game1.getPosition(), true);
						//p.addObject(o2);
						Vector3 b(455, 0, -165);
						game.setPosition(b);
						Vector3 c(455, 12 ,- 165);
						game1.setPosition(c);
						Vector3 d(455, 12 ,- 127);
						game2.setPosition(d);
						Vector3 e(455, 0,- 127);
						game3.setPosition(e);

						p.setGoal(game3.getPosition(), game2.getPosition(),  game1.getPosition(), game.getPosition(), RADIUS_KALE);
						IAnimatedMesh *model_top = smgr->getMesh("../media/football.3ds");
						if (!model_top)
							return 1;
						IAnimatedMeshSceneNode *model_top_node = smgr->addAnimatedMeshSceneNode(model_top);
						//Load texture
						if (model_top_node)
						{
							//ITexture *texture = driver->getTexture("../../media/sydney.bmp");
							//model_node->setMaterialTexture(0, texture);
							model_top_node->setMD2Animation(scene::EMAT_RUN);
							//Disable lighting (we've got no light)
							model_top_node->setMaterialFlag(EMF_LIGHTING, false);
							model_top_node->setScale(model_top_node->getScale() * 0.5);
							model_top_node->setPosition(core::vector3df(x, y, z));
		
						}
	
						float glove1_x = 456;
						float glove1_y = 8;
						float glove1_z = -138;

						float glove2_x = 456;
						float glove2_y = 8;
						float glove2_z = -158;	
	
						IAnimatedMesh *model_glove1 = smgr->getMesh("../media/eldiven_sag.obj");
						if (!model_glove1)
							return 1;
						IAnimatedMeshSceneNode *model_glove1_node = smgr->addAnimatedMeshSceneNode(model_glove1);
						//Load texture
						if (model_glove1_node)
						{
							//ITexture *texture = driver->getTexture("../../media/sydney.bmp");
							//model_node->setMaterialTexture(0, texture);
							model_glove1_node->setMD2Animation(scene::EMAT_RUN);
							//Disable lighting (we've got no light)
							model_glove1_node->setMaterialFlag(EMF_LIGHTING, false);
							model_glove1_node->setScale(model_glove1_node->getScale() * 50 );
							//model_glove1_node->setRotation(core::vector3df(0, -180, 0));
							model_glove1_node->setPosition(core::vector3df(glove1_x, glove1_y, glove1_z));
	
	
						}
	
	
	
						IAnimatedMesh *model_glove2 = smgr->getMesh("../media/eldiven_sol.obj");
						if (!model_glove2)
							return 1;
						IAnimatedMeshSceneNode *model_glove2_node = smgr->addAnimatedMeshSceneNode(model_glove2);
						//Load texture
						if (model_glove2_node)
						{
							//ITexture *texture = driver->getTexture("../../media/sydney.bmp");
							//model_node->setMaterialTexture(0, texture);
							model_glove2_node->setMD2Animation(scene::EMAT_RUN);
							//Disable lighting (we've got no light)
							model_glove2_node->setMaterialFlag(EMF_LIGHTING, false);
							model_glove2_node->setScale(model_glove2_node->getScale() * 50 );
							//model_glove2_node->setRotation(core::vector3df(0, -180, 0));
							model_glove2_node->setPosition(core::vector3df(glove2_x, glove2_y, glove2_z));

						}
	
	
						//Load map
	
						// Create 3 fixed and one user-controlled cameras
						//Front
						camera[0] = smgr->addCameraSceneNode(0, vector3df(420, 15, -150), vector3df(500, 5, -150));
						//Top
	
						//User-controlled
						camera[1] = smgr->addCameraSceneNodeFPS();
						// don't start at sydney's position
						if (camera[1])
							camera[1]->setPosition(core::vector3df(530, 7, -150));
						camera[1]->setRotation(core::vector3df(0, 0, 0));

						/*
						Create a variable for counting the fps and hide the mouse:
						*/
						//Hide mouse
						device->getCursorControl()->setVisible(false);
						//We want to count the fps
						int lastFPS = -1;


						game4.setPosition(Vector3(456,8,-138));
						game3.setPosition(Vector3(456,8,-158));
						bool ballHit=false, isGoal=false;
						bool isVibrate=true;
						int i=0;
						bool isNotGoal = true;
						p.setBallPositionVelocity();
						Vector3 rotation;
						while(1){
							
							struct timeval startTime,currentTime;
							struct timeval startH,currentH;
							while (device->run())
							{
								gettimeofday(&startH,NULL);
								stringw infoText,vibrate,directionStr;
								++counter;
								Vector3 abc = hard.getBallVelocity();
								Vector3 direction=hard.getBallDirection();
								infoText += stringw("DEBUG INFORMATION \n");
								infoText += stringw(L"Ball Velocity:  ");
								infoText += stringw(abc.getX());
								infoText += stringw("/");
								infoText += stringw(abc.getY());
								infoText += stringw("/");
								infoText += stringw(abc.getZ());
								infoText += stringw(L"\n");
								infoText += stringw(L"Ball Direction:  ");
								infoText += stringw(direction.getX());
								infoText += stringw("/");
								infoText += stringw(direction.getY());
								infoText += stringw("/");
								infoText += stringw(direction.getZ());
								infoText += stringw(L"\n");
									//printf("%10f%10f%10f",abc.getX(),abc.getY(),abc.getZ());
								if(hard.getIsBallHit() && !ballHit){
									ballHit=true;
									p.setVelocityBall(abc);
									gettimeofday(&startTime,NULL);
								}
							gettimeofday(&currentTime,NULL);
							
														
							int sec;
	                              
							sec = currentTime.tv_sec - startTime.tv_sec;                         
					
							if(ballHit && sec > 6 && isNotGoal){
							
								if(!isGoal){
									sound_Notgoal.play();
								
								}

								isNotGoal = false;
							}
							if (isEnter) {    
								isNotGoal = true;
								hard.resetBall();
								hard.resetRHand();
								hard.resetLHand();
								sound_goal.stop();
								sound_Notgoal.stop();
								isVibrate=true;
								p.setBallPositionVelocity();
								p.setLeftVibrate(false);
								p.setRightVibrate(false);
								i=0;
								isGoal = false;
								
								ballHit=false;
								isEnter  = 0;						
	
								camera[1]->setPosition(core::vector3df(530, 7, -150));
							}
						

								//Set the viewpoint to the whole screen and begin scene
								driver->setViewPort(rect<s32>(0, 0, ResX, ResY));
								driver->beginScene(true, true, SColor(255, 100, 100, 100));
									model_top_node->setFrameLoop(-1, 1);
									
									Vector3 right=hard.getRHandLocation();
									Vector3 left=hard.getLHandLocation();
									p.setGlove(right,left);//burdaki vekt�rler donan�mdan gelicek eldiveblerin pozisyonu
									infoText += stringw(L"R Hand Location:  ");
									infoText += stringw(right.getX());
									infoText += stringw("/");
									infoText += stringw(right.getY());
									infoText += stringw("/");
									infoText += stringw(right.getZ());
									infoText += stringw(L"\n");
									infoText += stringw(L"L Hand Location:  ");
									infoText += stringw(left.getX());
									infoText += stringw("/");
									infoText += stringw(left.getY());
									infoText += stringw("/");
									infoText += stringw(left.getZ());
									infoText += stringw(L"\n");
									p.update(UPDATE);
				
									if(p.getRightVibrate()){
										infoText += stringw(L"VibrateLeft\n");
									}
									if(p.getRightVibrate()&&isVibrate){
										hard.vibrateLHand();																												
										isVibrate=false;
									}
									if(p.getLeftVibrate()){
										infoText += stringw(L"VibrateRight\n");
									}
									if(p.getLeftVibrate()&&isVibrate){	
										hard.vibrateRHand();													
										isVibrate=false;
									}
									if(isDebugMode){																
 										Context.InfoStatic->setText(infoText.c_str());
							}
							
									Vector3 s1 = p.getBall();
									Vector3 s4=p.getVelocity();
									game1.setPosition(s4);
									game.setPosition(s1);
									if(p.isStop()){
										model_top_node->setRotation(core::vector3df(0,0,0));
									}
									else{
										Vector3 vel = p.getVelocity();
										gameEngine game5;
										rotation = rotation + vel;
										model_top_node->setRotation(core::vector3df(-rotation.getX(), 0, rotation.getZ()));
										i +=8;
									}


									model_top_node->setPosition(core::vector3df(game.getPosition().getX(),game.getPosition().getY(),game.getPosition().getZ()));
				
				
									//burda eldivenleri bast�rs�n
									Vector3 s2=p.getGloveLeft();
									Vector3 s3=p.getGloveRight();
									game.setPosition(s2);
									game1.setPosition(s3);
									model_glove1_node->setPosition(core::vector3df(game.getPosition().getX(),game.getPosition().getY(),game.getPosition().getZ()));//gloveLeft
									model_glove2_node->setPosition(core::vector3df(game1.getPosition().getX(),game1.getPosition().getY(),game1.getPosition().getZ()));//gloveRight
			
									/*ILogger* logger = device->getLogger(); 

									logger->log("The text u want to write");*/
		
								//If SplitScreen is used
								if (SplitScreen)
								{
									//Activate camera1
									smgr->setActiveCamera(camera[0]);
									//Set viewpoint to the first quarter (left top)
									driver->setViewPort(rect<s32>(0, 0, ResX/2, ResY));
									//Draw scene
									smgr->drawAll();
									//Activate camera2
			
									//Set viewport the last quarter (right bottom)
									driver->setViewPort(rect<s32>(ResX / 2, 0, ResX, ResY));
								}
								//Activate camera4
								smgr->setActiveCamera(camera[1]);
								//Draw scene
								smgr->drawAll();
								env_2->drawAll();
/*
										core::stringw tmp = "HELLLOOOOO ";
									env_2->addStaticText(
									L"Press 'W' to change wireframe mode\nPress 'D' to toggle detail map\nPress 'S' to toggle skybox/skydome",
									core::rect<s32>(10,421,500,475), true, true, 0, -1, true);*/
								//
	
								driver->endScene();
									
								//Get and show fps
								if (driver->getFPS() != lastFPS)
								{
									lastFPS = driver->getFPS();
									core::stringw tmp = L"CSE395 - Group 1 (FPS: ";
									tmp += lastFPS;
									tmp += ")";
									device->setWindowCaption(tmp.c_str());
								}
								gettimeofday(&currentH,NULL);	
								int usec = (currentH.tv_usec - startH.tv_usec) + ((currentH.tv_sec - startH.tv_sec) * 1000000);
								//printf("usec::%d\n",usec);
								if(usec <UPDATE * 1000000)						
								device->sleep(UPDATE*1000 - (usec/1000));
								if (p.isGoal() && !isGoal){///(goall)
									camera[1]->setPosition(core::vector3df(400, 9, -150));
									sound_goal.play();			
									isGoal = true;
								}
			
							}				
				
						}
		
		
							//if (game.getPosition().getX() == 455 && game.getPosition().getZ() > -166 && game.getPosition().getZ() < -129 && game.getPosition().getY() < 12)///(goall)
								//camera[1]->setPosition(core::vector3df(400, 9, -150));

	
						//Delete device
						device->drop();
						return 0;

										}
										return true;
									}
									break;

								default:
									break;
								}
							}
		
							return false;
						}

					private:
						SAppContext & Context;
					};


/*
Ok, now for the more interesting part. First, create the Irrlicht device. As in
some examples before, we ask the user which driver he wants to use for this
example:
*/
int main()
{
		hard.startHardware("",5);	
	// ask user for driver
	video::E_DRIVER_TYPE driverTypeGui=EDT_OPENGL ;
	if (driverTypeGui==video::EDT_COUNT)
		return 1;

	// create device and exit if creation failed

	IrrlichtDevice * deviceGui = createDevice(driverTypeGui, core::dimension2d<u32>(640, 480));

	if (deviceGui == 0)
		return 1; // could not create selected driver.

	/* The creation was successful, now we set the event receiver and
		store pointers to the driver and to the gui environment. */

	deviceGui->setWindowCaption(L"Penalty Simulation");
	deviceGui->setResizable(true);

	video::IVideoDriver* driverGui = deviceGui->getVideoDriver();
	IGUIEnvironment* env = deviceGui->getGUIEnvironment();

	/*
	To make the font a little bit nicer, we load an external font
	and set it as the new default font in the skin.
	To keep the standard font for tool tip text, we set it to
	the built-in font.
	*/

	IGUISkin* skin = env->getSkin();
	IGUIFont* font = env->getFont("../media/fonthaettenschweiler.bmp");
	if (font)
		skin->setFont(font);

	skin->setFont(env->getBuiltInFont(), EGDF_TOOLTIP);

	/*
	We add three buttons. The first one closes the engine. The second
	creates a window and the third opens a file open dialog. The third
	parameter is the id of the button, with which we can easily identify
	the button in the event receiver.
	*/	
	env->addImage(driverGui->getTexture("../media/soccer_ball.png"),
			position2d<int>(0,0));

	env->addButton(rect<s32>(10,270,110,240 + 80), 0, GUI_ID_NEW_GAME,
			L"New Game", L"Start New Game");

	env->addButton(rect<s32>(10,330,110,290 + 90), 0, GUI_ID_QUIT_BUTTON,
			L"Quit", L"Exits Program");
	



	// Store the appropriate data in a context structure.
	SAppContext context;
	context.Device = deviceGui;
	//context.Counter = 0;

	// Then create the event receiver, giving it that context structure.
	MyEventReceiverGui receiver(context);

	// And tell the device to use our custom event receiver.
	deviceGui->setEventReceiver(&receiver);



	/*
	That's all, we only have to draw everything.
	*/

	while(deviceGui->run() && driverGui)
	if (deviceGui->isWindowActive())
	{
		driverGui->beginScene(true, true, SColor(0,200,200,200));

		env->drawAll();
	
		driverGui->endScene();
	}

	deviceGui->drop();

	return 0;
}

/*
**/
