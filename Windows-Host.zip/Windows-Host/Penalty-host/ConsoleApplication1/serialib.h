/*!
\file    serialib.h
\brief   Serial library to communicate throught serial port, or any device emulating a serial port.
\author  Philippe Lucidarme (University of Angers) <serialib@googlegroups.com>
\version 1.2
\date    28 avril 2011
This Serial library is used to communicate through serial port.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE X CONSORTIUM BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

This is a licence-free software, it can be used by anyone who try to build a better world.
*/


#ifndef SERIALIB_H
#define SERIALIB_H
#if defined (_WIN32) || defined( _WIN64)
// Accessing to the serial port under Windows
#include <windows.h>
#include <time.h>


// Include for Linux


/*!  \class serialib
\brief     This class can manage a serial port. The class allows basic operations (opening the connection, reading, writing data and closing the connection).
\example   Example1.cpp
*/

int gettimeofday(struct timeval * tp, struct timezone * tzp);
class serialib
{
public:
	// Constructor of the class
	serialib();

	// Destructor
	~serialib();



	//_________________________________________
	// ::: Configuration and initialization :::


	// Open a device
	char    Open(const char *Device, const unsigned int Bauds);

	// Close the current device
	void    Close();



	//___________________________________________
	// ::: Read/Write operation on characters :::


	// Write a char
	char    WriteChar(char);

	// Read a char (with timeout)
	char    ReadChar(char *pByte, const unsigned int TimeOut_ms = NULL);



	//________________________________________
	// ::: Read/Write operation on strings :::


	// Write a string
	char    WriteString(const char *String);
	// Read a string (with timeout)
	int     ReadString(char *String,
		char FinalChar,
		unsigned int MaxNbBytes,
		const unsigned int TimeOut_ms = NULL);



	// _____________________________________
	// ::: Read/Write operation on bytes :::


	// Write an array of bytes
	char    Write(const void *Buffer, const unsigned int NbBytes);

	// Read an array of byte (with timeout)
	int     Read(void *Buffer, unsigned int MaxNbBytes, const unsigned int TimeOut_ms = NULL);


	// _________________________
	// ::: Special operation :::


	// Empty the received buffer
	void    FlushReceiver();

	// Return the number of bytes in the received buffer
	int     Peek();

private:
	// Read a string (no timeout)
	int     ReadStringNoTimeOut(char *String, char FinalChar, unsigned int MaxNbBytes);


	HANDLE          hSerial;
	COMMTIMEOUTS    timeouts;

};



/*!  \class     TimeOut
\brief     This class can manage a timer which is used as a timeout.
*/
// Class TimeOut
class TimeOut
{
public:

	// Constructor
	TimeOut();

	// Init the timer
	void                InitTimer();

	// Return the elapsed time since initialization
	unsigned long int   ElapsedTime_ms();

private:
	struct timeval      PreviousTime;
};
#else

#include "rs232.h"

#include <stdlib.h>
#include <stdio.h>


#include <unistd.h>




/*!  \class serialib
\brief     This class can manage a serial port. The class allows basic operations (opening the connection, reading, writing data and closing the connection).
\example   Example1.cpp
*/


class serialib
{
public:

	int i;
	int n;
	int cport_nr;        /* /dev/ttyS0 (COM1 on windows) */
	unsigned char buf[4096];
	// Constructor of the class
	serialib();

	// Destructor
	~serialib();



	//_________________________________________
	// ::: Configuration and initialization :::


	// Open a device
	char    Open(int cport_nr, const unsigned int Bauds);

	// Close the current device
	void    Close();



	//___________________________________________
	// ::: Read/Write operation on characters :::


	// Write a char
	


	//________________________________________
	// ::: Read/Write operation on strings :::


	// Write a string
	char    WriteString(const char *String);
	// Read a string (with timeout)
	int     ReadString(char *String, char FinalChar, unsigned int MaxNbBytes, unsigned int TimeOut_ms);



	// _____________________________________
	// ::: Read/Write operation on bytes :::


	// Write an array of bytes

	// _________________________
	// ::: Special operation :::


	// Empty the received buffer
	
	// Return the number of bytes in the received buffer
};



/*!  \class     TimeOut
\brief     This class can manage a timer which is used as a timeout.
*/
// Class TimeOut
#endif // SERIALIB_H
#endif
