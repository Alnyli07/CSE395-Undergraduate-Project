#ifndef BALL_H
#define BALL_H


class Ball : public Collider
{
public:

		Ball(const Vector3& center, float radius) :
		Collider(Collider::TYPE_BALL),
		center(center),
		radius(radius) {}

	
	Collision collisionBall(const Ball& other) const
	{
		float radiusDistance = radius + other.getRadius();
		Vector3 direction = (other.getCenter() - center);
		float centerDistance = direction.length();
		direction /= centerDistance;

		float distance = centerDistance - radiusDistance;

		return Collision(distance < 0, direction * distance);
	}

	void transform(const Vector3& translation)
	{
		center += translation;
	}
	
	Vector3 getCenter() const
	{ 
		return center; 
	}

	inline float getRadius() const { return radius; }


private:

	Vector3 center;
	float    radius;
};

#endif