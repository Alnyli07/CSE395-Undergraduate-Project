#include "gameEngine.h"


//default constructor
gameEngine::gameEngine()
{
	posOfBall.setX(0);
	posOfBall.setY(-90);
	posOfBall.setZ(200);
	speed = 0;
}

//constructor for game engine
gameEngine::gameEngine(Vector3 vector,float speed)
{
	posOfBall.setX(-(vector.getZ()));
	posOfBall.setY(-(vector.getX()));
	posOfBall.setZ(vector.getY());
	speed = 0;

}

// set initial position of score ball
void gameEngine::setInitialPosition(Vector3 vector)
{
	posOfBall.setX(0);
	posOfBall.setY(-90);
	posOfBall.setZ(200);
}

// get initial position of score ball
Vector3 gameEngine::getInitalPosition()
{
	posOfBall.set(0,-90,200);
	return this->posOfBall;
}

// setter for speed
void gameEngine::setSpeed(float speed)
{
	this->speed = speed;
}

// getter for speed
float gameEngine::getSpeed()
{
	return (this->speed);
}

// setter for position of ball
void gameEngine::setPosition(Vector3 vector)
{
	posOfBall.setX(-(vector.getZ()));
	posOfBall.setY((vector.getY()));
	posOfBall.setZ(-(vector.getX()));
}

// getter for position of ball
Vector3 gameEngine::getPosition()
{
	return (this->posOfBall);
}


    