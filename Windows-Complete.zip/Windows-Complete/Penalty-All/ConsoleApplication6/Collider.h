#ifndef COLLIDER_H
#define COLLIDER_H

#include "Collision.h"

class Collider
{
public:

	enum
	{
		TYPE_BALL
	};

	Collider(int t) :
		type(t) {}
	

Collision collision(const Collider& other) const;

	virtual void transform(const Vector3& translation) {}

	virtual Vector3 getCenter() const { return Vector3(0,0,0); }

	
	inline int getType() const { return type; }
private:

	int type;
};


#endif