#ifndef HARDWARE_H
#define HARDWARE_H
//#include "mySocket.h"
#include "Vector3.h"
#include "quaternion.h"
#include "quaternion.cpp"
#include <stdio.h>

#define ACCELRANGE 16
#define GYRORANGE 2000
#define GRAVITY 9.7
#define PI 3.14159265359
#if defined (_WIN32) || defined( _WIN64)
#include "serialib.h"
#include<Windows.h>
#include<process.h>
#endif
#ifdef __linux__
#include <pthread.h>
#include <semaphore.h>
#endif
class hardware{
private:
	bool isBallHit;
	bool exit;
#if defined (_WIN32) || defined( _WIN64)
	
	serialib ball;
	serialib rHand;
	serialib lHand;
	HANDLE ballThread;
	HANDLE rHandThread;
	HANDLE lHandThread;
	HANDLE ballSemaphore;
	HANDLE rHandSemaphore;
	HANDLE lHandSemaphore;
	int xDir;
	static void calculateBall(void *a);
	static void calculateRHand(void *a);
	static void calculateLHand(void *a);
	void lockBall();
	void unlockBall();
	void lockRHand();
	void unlockRHand();
	void lockLHand();
	void unlockLHand();
	
#endif
#ifdef __linux__
	pthread_t socketThread;
	sem_t socketSemaphore;
	mySocket socket;
	static void* connectSocket(void *a);
	void lockSocket();
	void unlockSocket();
#endif
	double ballDirection[3];
	double ballVelocity[3];
	double rHandShoulderDirection[3];
	double rHandArmDirection[3];
	double lHandShoulderDirection[3];
	double lHandArmDirection[3];
	double ballaRefs[3];
	int ballgRefs[3];
	int rHandgRefs[6];
	int lHandgRefs[6];
	
public:
	hardware();
	int startHardware(char *ip, int port);
	bool getIsBallHit();
	void resetHardware();
	Vector3 getBallDirection();
	Vector3 getBallVelocity();
	Vector3 getRHandLocation();
	Vector3 getLHandLocation();
	Vector3 getRHandShoulderDirection();
	Vector3 getLHandShoulderDirection();
	Vector3 getRHandArmDirection();
	Vector3 getLHandArmDirection();
	void resetBall();
	void resetRHand();
	void resetLHand();
	void vibrateRHand();
	void vibrateLHand();
	int endHardware();
};

#endif