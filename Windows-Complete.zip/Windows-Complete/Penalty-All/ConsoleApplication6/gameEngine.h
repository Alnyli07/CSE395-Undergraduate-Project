#ifndef GAMEENGINE_H
#define GAMEENGINE_H

#include "Vector3.h"


class gameEngine
{
public:
	
	gameEngine();
	gameEngine(Vector3 posOfBall,float speed);
	void setInitialPosition(Vector3 vector);
	Vector3 getInitalPosition();
	void setSpeed(float speed);
	float getSpeed();
	void setPosition(Vector3 vector);
	Vector3 getPosition();


private:
	 Vector3 posOfBall;
	 float speed;

};

#endif