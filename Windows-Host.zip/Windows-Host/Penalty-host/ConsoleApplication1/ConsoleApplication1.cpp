#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#include "Hardware.h"

// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")
//#pragma comment (lib, "Mswsock.lib")

#define DEFAULT_PORT "27015"

int main(void)
{
	WSADATA wsaData;
	int iResult;
	char portNumber[10];
	SOCKET ListenSocket = INVALID_SOCKET;
	SOCKET ClientSocket = INVALID_SOCKET;

	struct addrinfo *result = NULL;
	struct addrinfo hints;

	int iSendResult;
	char recvbuf, sendData[512];

	fd_set ReadFDs;
	FD_ZERO(&ReadFDs);

	hardware h;
	h.startHardware("",3);
	
	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed with error: %d\n", iResult);
		h.endHardware();
		return 1;
	}
	char ac[80];
    gethostname(ac, sizeof(ac));
    struct hostent *phe = gethostbyname(ac);
    for (int i = 0; phe->h_addr_list[i] != 0; ++i) {
        struct in_addr addr;
        memcpy(&addr, phe->h_addr_list[i], sizeof(struct in_addr));
        cout << "Address " << i << ": " << inet_ntoa(addr) << endl;
    }
	cout << "Enter port number:";
	cin >> portNumber;
	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;

	// Resolve the server address and port
	iResult = getaddrinfo(NULL, portNumber, &hints, &result);
	if (iResult != 0) {
		printf("getaddrinfo failed with error: %d\n", iResult);
		WSACleanup();
		h.endHardware();
		return 1;
	}

	// Create a SOCKET for connecting to server
	ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
	if (ListenSocket == INVALID_SOCKET) {
		printf("socket failed with error: %ld\n", WSAGetLastError());
		freeaddrinfo(result);
		WSACleanup();
		h.endHardware();
		return 1;
	}

	// Setup the TCP listening socket
	iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
	if (iResult == SOCKET_ERROR) {
		printf("bind failed with error: %d\n", WSAGetLastError());
		freeaddrinfo(result);
		closesocket(ListenSocket);
		WSACleanup();
		h.endHardware();
		return 1;
	}
	
	freeaddrinfo(result);

	iResult = listen(ListenSocket, SOMAXCONN);
	if (iResult == SOCKET_ERROR) {
		printf("listen failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		h.endHardware();
		return 1;
	}

	// Accept a client socket
	ClientSocket = accept(ListenSocket, NULL, NULL);
	if (ClientSocket == INVALID_SOCKET) {
		printf("accept failed with error: %d\n", WSAGetLastError());
		closesocket(ListenSocket);
		WSACleanup();
		h.endHardware();
		return 1;
	}

	// No longer need server socket
	
	closesocket(ListenSocket);
	
	// Receive until the peer shuts down the connection
	
	do {
		timeval	timeOut;
		timeOut.tv_sec = 0;
		timeOut.tv_usec = 10000;
		
		if (printf("%d", iResult) && (iResult = select(0, &ReadFDs, NULL, NULL, &timeOut) > 0)){
			iResult = recv(ClientSocket, &recvbuf, 1, 0);
			if (iResult > 0){
				if (recvbuf == 'r')
					h.vibrateRHand();
				if (recvbuf == 'l')
					h.vibrateLHand();
				if (recvbuf == 's'){
					//h.resetHardware();
					h.resetBall();
					h.resetRHand();
					h.resetLHand();
				}
			}
			else if (iResult == 0){
				printf("Connection closing...\n");
				getchar();
				break;
			}
			else  {
				printf("recv failed with error: %d\n", WSAGetLastError());
				closesocket(ClientSocket);
				WSACleanup();
				h.endHardware();
				getchar();
				return 1;
			}
		}
		else
			FD_SET(ClientSocket, &ReadFDs);
		//printf("Bytes received: %d\n", iResult);

		// Echo the buffer back to the sender
		Vector3 bv = h.getBallVelocity(), bd = h.getBallDirection(), rhsd = h.getRHandShoulderDirection(), rhad = h.getRHandArmDirection(),
			lhsd = h.getLHandShoulderDirection(), lhad = h.getLHandArmDirection();
		sprintf_s(sendData, "%.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %d\n",
			bv.getX(), bv.getY(), bv.getZ(), bd.getX(), bd.getY(), bd.getZ(), 
			rhsd.getX(), rhsd.getY(), rhsd.getZ(), rhad.getX(), rhad.getY(), rhad.getZ(),
			lhsd.getX(), lhsd.getY(), lhsd.getZ(), lhad.getX(), lhad.getY(), lhad.getZ(),
			h.getIsBallHit());
		printf(sendData);
		iSendResult = send(ClientSocket, sendData,strlen(sendData),0);
		if (iSendResult == SOCKET_ERROR) {
			printf("send failed with error: %d\n", WSAGetLastError());
			closesocket(ClientSocket);
			WSACleanup();
			h.endHardware();
			getchar();
			return 1;
		}
	

	} while (1);

	// shutdown the connection since we're done
	iResult = shutdown(ClientSocket, SD_SEND);
	if (iResult == SOCKET_ERROR) {
		printf("shutdown failed with error: %d\n", WSAGetLastError());
		closesocket(ClientSocket);
		WSACleanup();
		h.endHardware();
		return 1;
	}

	// cleanup
	closesocket(ClientSocket);
	WSACleanup();
	h.endHardware();
	return 0;
}