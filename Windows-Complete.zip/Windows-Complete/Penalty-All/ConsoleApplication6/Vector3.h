#ifndef VECTOR_H
#define VECTOR_H
#include <math.h>
#define ZERO_NUM 0.0001f
class Vector3
{
public:

	public:
	Vector3(float x = 0) 
	{
		this->x = x;
		this->y = x;
		this->z = x;
	}
	
	Vector3(const Vector3& other)
	{
		this->x = other.x;
		this->y = other.y;
		this->z = other.z;
	}
	
	Vector3(float x, float y, float z)
	{
		if(x > -ZERO_NUM && x < ZERO_NUM)
			this->x = 0;
		else
			this->x = x; 
		if(y > -ZERO_NUM && y < ZERO_NUM)
			this->y = 0;
		else
			this->y = y; 
		if(z > -ZERO_NUM && z < ZERO_NUM)
			this->z = 0;
		else
			this->z = z; 

	}
	
	inline Vector3 cross(const Vector3 other) const
	{
		float x = this->y * other.getZ() - this->z * other.getY();
		float y = this->z * other.getX() - this->x * other.getZ();
		float z = this->x * other.getY() - this->y * other.getX();

		return Vector3(x, y, z);
	}

	inline Vector3 rotate(float angle, const Vector3& axis) const
	{
		const float sinAngle = sin(-angle);
		const float cosAngle = cos(-angle);
		
		return this->cross(axis * sinAngle) +        //Rotation on local X
			(*this * cosAngle) +                     //Rotation on local Z
		    axis * this->dot(axis * (1 - cosAngle)); //Rotation on local Y
	}

	inline Vector3 operator+(const Vector3& other) const 
	{ 
		return Vector3(getX() + other.getX(), getY() + other.getY(), getZ() + other.getZ());
	}


	inline Vector3 operator-(const Vector3&other) const 
	{ 
		return Vector3(getX() -other.getX(), getY() -other.getY(), getZ() -other.getZ());
	}

	inline Vector3 operator*(float f) const
	{ 
		return Vector3(getX() * f, getY() * f, getZ() * f); 
	}

	inline Vector3 operator/(float f) const 
	{ 
		return Vector3(getX() / f, getY() / f, getZ() / f); 
	}

	inline bool operator==(const Vector3&other) const 
	{ 
		return getX() ==other.getX() && getY() ==other.getY() && getZ() ==other.getZ(); 
	}

	inline bool operator!=(const Vector3&other) const 
	{ 
		return !operator==(other); 
	}

	inline Vector3& operator+=(const Vector3&other)
	{
		this->x +=other.getX();
		this->y +=other.getY();
		this->z +=other.getZ();

		return *this;
	}

    inline Vector3& operator-=(const Vector3&other)
    {
		this->x -=other.getX();
		this->y -=other.getY();
		this->z -=other.getZ();

		return *this;
    }
    
    inline Vector3& operator*=(float f)
    {
		this->x *= f;
		this->y *= f;
		this->z *= f;

		return *this;
    }
    
	inline Vector3& operator/=(float f)
	{
		this->x /= f;
		this->y /= f;
		this->z /= f;

		return *this;
	}

	inline float length() const
	{ 
		return sqrtf(getX() * getX() + getY() * getY() + getZ() * getZ());
	}

	inline float dot(const Vector3& other) const
	{
		return getX() * other.getX() + getY() * other.getY() + getZ() * other.getZ();
	}

	/* The actual formula for reflecting a vector then is:
                                              Vnew =  V + - N*(V dot N) * 2            */
	inline Vector3 reflect(const Vector3& normal) const
	{
		return *this - (normal * (this->dot(normal) * 2));
	}

    inline Vector3 normalized() const
	{
		const float length = this->length();

		return Vector3(getX() / length, getY() / length, getZ() / length);
	}
	inline float getX() const {return this->x; }
	inline float getY() const {return this->y; }
	inline float getZ() const {return this->z; }
	
	inline void setX(const float& x) {
		if(x > -ZERO_NUM && x < ZERO_NUM)
			this->x = 0;
		else
			this->x = x; 
	}
	inline void setY(const float& y) {
		if(y > -ZERO_NUM && y < ZERO_NUM)
			this->y = 0;
		else
			this->y = y; 
	}
	inline void setZ(const float& z) { 
		if(z > -ZERO_NUM && z < ZERO_NUM)
			this->z = 0;
		else
			this->z = z; 
	}
	
	inline void set(const float& x, const float& y, const float& z) { setX(x); setY(y); setZ(z); }

private:
	float x,y,z;
};

#endif