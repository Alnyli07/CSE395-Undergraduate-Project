#include "stdafx.h"
#include "Vector3.h"


Vector3::Vector3(void)
{
}


Vector3::~Vector3(void)
{
}
