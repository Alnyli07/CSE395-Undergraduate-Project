#ifndef OBJECT_H
#define OBJECT_H

#include "Collider.h"
#include <iostream>
#define ZERO 1
class PhysicObj
{
public:

	PhysicObj(Collider* collider, const Vector3& velocity, bool stat) :
		position(collider->getCenter()),
		oldPosition(collider->getCenter()),
		velocity(velocity),
		collider(collider),isStatic(stat){}
	PhysicObj(const PhysicObj& other) :
		position(other.position),
		oldPosition(other.oldPosition),
		velocity(other.velocity),
		collider(other.collider),isStatic(other.isStatic)
	{
		
	}

	void operator=(PhysicObj other)
	{
		//Implemented using the copy/swap idiom.
		char* temp[sizeof(PhysicObj)/sizeof(char)];
		memcpy(temp, this, sizeof(PhysicObj));
		memcpy(this, &other, sizeof(PhysicObj));
		memcpy(&other, temp, sizeof(PhysicObj));
	}

	~PhysicObj(){ }

	void integrate(float delta)
	{
		oldPos = position;
		if(!_isnan(velocity.getY() - ( delta * 9.8f )))
		{	velocity.setY(velocity.getY() - ( delta * 9.8f ));
			Vector3 pos = velocity * delta;
			position += pos;
		}

		/*std::cout << "Ball: " << position.getX() << " | " << position.getY() << " | " <<
			position.getZ() << " |\n ";*/
	/**	int a ;
		std::cin >> a;*/
	}

	/** Basic getter */
	inline const Vector3& getPosition() const { return position; }
	/** Basic getter */
	inline const Vector3& getVelocity() const { return velocity; }
	inline const bool getStatic() const { return isStatic; }
	inline  void setStatic(bool set)  { this->isStatic = set; }


	inline const Collider& getCollider()
	{
		//Find distance between current and old position
		Vector3 translation = position - oldPosition;
		//Update old position back to current position.
		oldPosition = position;
		//Move collider by distance moved.
		collider->transform(translation);

		return *collider;
	}

	/** Basic setter,get */
	inline void setVelocity(const Vector3& velocity){ 
		this->velocity = velocity;
		/*if(this->velocity.getX() > -ZERO && this->velocity.getX() < ZERO)
			this->velocity.setX(0);
		if(this->velocity.getZ() > -ZERO && this->velocity.getZ() < ZERO)
			this->velocity.setZ(0);
		if(this->velocity.getY() > -ZERO && this->velocity.getY() < ZERO)
			this->velocity.setY(0);   */
	}

	inline void setPosition(const Vector3& position) { this->position = position; }
	inline Vector3 getOldPos(){return this->oldPos; }

private:
	/** Where this object is in 3D space. */
	Vector3 position,oldPos;
	/** The position of the object when the collider was last updated. */
	Vector3 oldPosition;
	/** How fast this object is moving and in what direction */
	Vector3 velocity;
	/** The colider representing the shape and position of this object. */
	Collider* collider;
	bool isStatic;
};
#endif